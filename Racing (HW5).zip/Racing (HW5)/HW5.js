var app = require('express')();
var server = require('http').Server(app);
var io = require('socket.io')(server);

var port = 3000;
server.listen (port, function() {
	console.log ('listening on port ' + port)
});

app.get('/', function(req, res){
  res.sendFile(__dirname + '/HW5.html');
});

var nID = 0;

// two-client turning status
var status = [];
var c0 = false, c1 = false;

io.on('connect', function(socket){

  //////////////////////////////////////////////////////////
  // things to do when a client connects
  console.log ('a user connected with socket ');

  // assign and return the ID of the new client
  console.log ('client ' + nID + ' login ...')
  socket.emit ('id_set', nID);

  // broadcast to all others of new client
  socket.broadcast.emit ('new_id', nID)

  // inform the status of all other clients ...
  // new kid needs to learn about old fellows

  status.push ({id: nID, turn: false});

  console.log (status);
  io.emit ('update_status', status)

  // this must be the LAST thing to do
  ++nID;

  //////////////////////////////////////////////////////////
  socket.on('accelerate', function(myID) {
  	let i;
  	for (i = 0; i < status.length; i++) {
  		if (status[i].id === myID) break;
  	}
 		status[i].turn = true;
 		console.log (status);
  	io.emit ('update_status', status);
  });

	socket.on('decelerate', function(myID) {
  	let i;
  	for (i = 0; i < status.length; i++) {
  		if (status[i].id === myID) break;
  	}
 		status[i].turn = false;
 		console.log (status);
  	io.emit ('update_status', status);
  });

	socket.on('loadOK', function(myID) {
		if(myID === 0) c0 = true;
		if(myID === 1) c1 = true;
		console.log("C0: " + c0 + "  C1: " + c1);
		if(c0 && c1) io.emit ('checkOK', 1000); //用socket.emit不行，待查證
		/*let i;
  	for (i = 0; i < status.length; i++) {
  		if (status[i].id === myID) break;
  	}
 		status[i].load = true;
		for (i = 0; i < status.length; i++) {
  		if (status[i].load === true) socket.broadcast.emit ('checkOK');
  	}*/
  });

	socket.on ('car_now', function (data) {
		let angle = data.angle;
		let x = data.x;
		let z = data.z;
		let omega = data.omega;
		let fuel = data.fuel;
		socket.broadcast.emit ('car_update', data);
  });
});
